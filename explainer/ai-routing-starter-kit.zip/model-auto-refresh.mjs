#!/usr/bin/env node
// model-auto-refresh.mjs — Standalone-safe local CLI model cache scanner & policy freshness checker.
// Works with ~/.claude/model-router/routing-policy.json OR local ./routing-policy.template.json.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const HOME = os.homedir();
const DRY = process.argv.includes('--dry-run');
const JSON_OUT = process.argv.includes('--json');

const policyCandidates = [
  path.join(HOME, '.claude', 'model-router', 'routing-policy.json'),
  path.join(__dirname, 'routing-policy.template.json'),
];
const policyPath = policyCandidates.find((p) => fs.existsSync(p));
const codexCachePath = path.join(HOME, '.codex', 'models_cache.json');

const discovered = [];
const detectedCaches = [];
if (fs.existsSync(codexCachePath)) {
  detectedCaches.push('codex:~/.codex/models_cache.json');
  try {
    const raw = JSON.parse(fs.readFileSync(codexCachePath, 'utf8'));
    const list = Array.isArray(raw?.models) ? raw.models : (Array.isArray(raw) ? raw : []);
    for (const m of list) {
      const id = m?.slug || m?.id;
      if (id) discovered.push(id);
    }
  } catch {}
}
for (const [name, p] of [
  ['claude', path.join(HOME, '.claude', 'settings.json')],
  ['antigravity', path.join(HOME, '.gemini', 'antigravity-cli')],
  ['grok', path.join(HOME, '.grok', 'config.toml')],
]) {
  if (fs.existsSync(p)) detectedCaches.push(`${name}:${p}`);
}

let policyAgeDays = null;
let policyDateSource = 'missing';
const promotions = [];
if (policyPath) {
  const policy = JSON.parse(fs.readFileSync(policyPath, 'utf8'));
  const st = fs.statSync(policyPath);
  const declared = policy.policyRevisionAt || policy.reviewedAt || policy.updated_at;
  const parsedMs = declared ? Date.parse(declared) : NaN;
  const refMs = Number.isFinite(parsedMs) ? parsedMs : st.mtimeMs;
  policyDateSource = Number.isFinite(parsedMs) ? `policy(${declared})` : 'file-mtime';
  policyAgeDays = Math.max(0, Math.floor((Date.now() - refMs) / 86400000));

  // Same-family minor promotion check for Codex (e.g. gpt-6.2-sol -> gpt-6.3-sol)
  const codexRoutes = policy.routes?.codex;
  if (codexRoutes && discovered.length > 0) {
    for (const [tier, cfg] of Object.entries(codexRoutes)) {
      const m = String(cfg?.model || '').match(/^(gpt-6)\.(\d+)-(sol|astra)$/);
      if (!m) continue;
      const curMinor = Number(m[2]);
      const suffix = m[3];
      const newer = discovered
        .map((id) => ({ id, mm: id.match(new RegExp(`^gpt-6\\.(\\d+)-${suffix}$`)) }))
        .filter((x) => x.mm && Number(x.mm[1]) > curMinor)
        .sort((a, b) => Number(b.mm[1]) - Number(a.mm[1]))[0];
      if (newer) {
        promotions.push({ host: 'codex', tier, from: cfg.model, to: newer.id });
        if (!DRY && process.argv.includes('--apply')) cfg.model = newer.id;
      }
    }
    if (!DRY && process.argv.includes('--apply') && promotions.length > 0) {
      policy.policyRevisionAt = new Date().toISOString();
      fs.writeFileSync(policyPath, JSON.stringify(policy, null, 2) + '\n', 'utf8');
    }
  }
}

const out = {
  ok: Boolean(policyPath),
  mode: DRY ? 'dry-run' : (process.argv.includes('--apply') ? 'apply' : 'check'),
  policyPath: policyPath || 'not-found',
  policyDateSource,
  policyAgeDays,
  fresh: policyAgeDays !== null && policyAgeDays <= 7,
  promotions,
  detectedCaches,
  discoveredCodexModels: discovered.slice(0, 12),
  checkedAt: new Date().toISOString(),
};
console.log(JSON.stringify(out, null, 2));
