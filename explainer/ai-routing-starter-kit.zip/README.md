# AI Subscription Routing & Quota-Optimization Starter Kit (16-File Packet)
Updated: 2026-11-22 EST | Zero external dependencies · Works standalone or with rUv's MetaHarness & RuvNet Brain

> **Enabling Technology Credit:** This playbook and starter kit build directly on the open-source **MetaHarness**, **MetaLLM**, **RuFlo**, **RuVector / AgentDB**, and **RuvNet Brain & Skills** ecosystem created by **Reuven Cohen (`rUv` / RuvNet)**. The 16 standalone files let you test the methodology in 2 minutes with plain Node.js, and upgrade seamlessly into the full RuvNet ecosystem whenever you're ready:
> - **MetaHarness Router (npm):** https://www.npmjs.com/package/@metaharness/router
> - **rUv / RuvNet Ecosystem (GitHub):** https://github.com/ruvnet
> - **RuvNet Brain (npm):** https://www.npmjs.com/package/ruvnet-brain

## 3-Step Quickstart (2 Minutes, 100% Local)
```bash
unzip ai-routing-starter-kit.zip -d ai-routing-kit && cd ai-routing-kit
node audit-my-ai-usage.mjs            # 1. Measure YOUR real 60-day score (0-100)
node standalone-router.mjs --eval     # 2. Verify 36/36 safety eval cases locally
node model-routing-audit.mjs          # 3. Run the watchdog self-audit
node app-model-router.mjs --smoke     # 4. Smoke-test Lens 2 production app router
```

## What's Inside (16 Standalone Files)
1. `README.md` — This quickstart guide and manifest
2. `SETUP-PROMPT.txt` — Copy-paste prompt for Claude Code, Antigravity, Codex, Grok, or Cursor
3. `audit-my-ai-usage.mjs` — Zero-dependency 60-day local usage auditor (Claude, Codex, Antigravity, Grok, Cursor)
4. `standalone-router.mjs` — Standalone 5-tier prompt classifier + 36-case eval runner
5. `policy.default.mjs` — 5-tier classification rules (`fast`, `medium`, `substantial`, `hard`, `exceptional`)
6. `routing-policy.template.json` — Canonical 4-host × 5-tier allocation + AA v5.0.1 effort caps
7. `routing-eval-cases.json` — 36-case routing safety regression suite
8. `app-model-router.mjs` — Fork 2 zero-hardcoded production app router (Admin UI picker + cacheable `/models` catalog + provider fallback + auto-escalation)
9. `model-auto-refresh.mjs` — Local CLI model cache scanner & freshness checker
10. `model-routing-audit.mjs` — Self-audit watchdog (works standalone or with MetaHarness)
11. `router-utilization.mjs` — Before-vs-after routing tier distribution analyzer
12. `MODEL-ROUTING-ARCHITECTURE.md` — Complete thought process, forensic drift timeline & architecture
13. `AI-Subscription-Routing-Playbook.md` — Full developer & enterprise playbook
14. `APP-MODEL-ROUTING-INTEGRATION.md` — Production app zero-hardcoded model standard
15. `examples/hooks-and-configs.md` — Drop-in configs for Claude Code, Codex, Grok, Cursor & production apps
16. `examples/statusline-50pct-compact.cjs` — Minimal 50% context `⚡/compact` statusline guard
