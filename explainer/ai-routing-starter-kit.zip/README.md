Updated: 2026-11-22 02:00:00 EST | Version 2.0.0

# AI Subscription Routing & Quota-Optimization Starter Kit (Complete 12-File Packet)

**Do NOT accept anything in this kit as gospel.** Run `node audit-my-ai-usage.mjs` first on your own machine (100% local, zero data leaves your computer). If you already score **85+/100**, your current setup is already beating our baseline—keep what works! If you score lower, every recipe, benchmark, thought-process doc, and watchdog in this packet is ready out of the box for you and your AI assistant to inspect, test, and customize.

## Complete Packet Contents (All Time & Date Stamped: 2026-11-22 02:00 EST)

### 1. Prove It On Your Own Data First
- `audit-my-ai-usage.mjs` — Zero-dependency 60-day local transcript auditor. Scores your current setup `0–100`, measures your exact Frontier %, Fast %, and Cache-Write volume, and tells you honestly whether you even need this kit.
- `SETUP-PROMPT.txt` — Copy-paste prompt to hand to your AI assistant (works whether or not you use MetaHarness).

### 2. Full Architecture, Evolution & Thought Process (The "Why", Not Just the Recipe)
- `AI-Subscription-Routing-Playbook.md` — Executive guide: Corporate "By-the-Drink" vs. Developer Prepaid Seats, Thinking-Level Economics (AA v5.0.1 / Vals v2.2 / KingBench 4), and the 4 Mandatory Quota-Hygiene Rules.
- `MODEL-ROUTING-ARCHITECTURE.md` — Complete technical architecture, forensic drift timeline (how a working router degrades over 60 days), diagnostic thought process, and 5-step rapid-recovery playbook.
- `APP-MODEL-ROUTING-INTEGRATION.md` — Lens 2 standard for deployed production apps (zero hardcoded model IDs).

### 3. Ready-to-Use Base Recipes (Modify Freely)
- `policy.default.mjs` — 5-tier (`fast | medium | substantial | hard | exceptional`) classifier + automatic failure escalation.
- `routing-policy.template.json` — 4-host × 5-tier model + thinking-level allocation capped at AA v5.0.1 efficiency sweet spots.
- `routing-eval-cases.json` — 36-case safety evaluation suite so you can test any custom edits without breaking hard-task safety.
- `model-routing-audit.mjs` — 13-point self-audit watchdog that alerts you immediately if hooks, `$0` API-key stripping, effort caps, or schedules drift.
- `model-auto-refresh.mjs` — Nightly/weekly auto-refresh script that discovers new local CLI models and promotes same-family upgrades automatically.
- `router-utilization.mjs` — Before-vs-After effectiveness & license-stretch tracker.
- `app-model-router.mjs` — Drop-in production app router module with externalized `APP_MODEL_TIERS_JSON` and automatic 1-retry validation escalation.
