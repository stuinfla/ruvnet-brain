#!/usr/bin/env node
// Minimal standalone 50% context ⚡/compact guard for Claude Code / Antigravity / Grok statuslines.
const fs = require('fs');
let data = {};
try { data = JSON.parse(fs.readFileSync(0, 'utf8') || '{}'); } catch {}
const pct = Math.round(data?.context_window?.used_percentage || 0);
const warn = pct >= 50 ? ' \x1b[1;31m⚡/compact\x1b[0m' : '';
const col = pct >= 65 ? '\x1b[1;31m' : pct >= 50 ? '\x1b[1;33m' : '\x1b[1;32m';
console.log(`${col}ctx ${pct}%\x1b[0m${warn} | $0 prepaid subscription mode`);
