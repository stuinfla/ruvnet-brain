# Drop-In Config & Hook Recipes (No MetaHarness Required)
Updated: 2026-11-22 EST

## 1. Claude Code (`~/.claude/settings.json`)
Park your main session on `sonnet` and add the 50% `⚡/compact` statusline guard:
```json
{
  "model": "sonnet",
  "statusLine": {
    "type": "command",
    "command": "node ~/.claude/statusline-50pct-compact.cjs"
  }
}
```

## 2. Codex CLI (`~/.codex/config.toml`)
Park Codex on `gpt-6.2-sol` (medium effort) and reserve `gpt-6.2-astra` for explicit escalations:
```toml
model = "gpt-6.2-sol"
model_reasoning_effort = "medium"
default_subagent_model = "gpt-6.2-sol"
```

## 3. Grok CLI (`~/.grok/config.toml`)
Park on `grok-4.7` (low/medium effort) and offload secondary work to `grok-build`:
```toml
model = "grok-4.7"
reasoning_effort = "low"
fork_secondary_model = "grok-build"
```

## 4. Cursor IDE (`.cursorrules` / Settings)
- Set default Composer/Chat model to **Claude Sonnet** or **Gemini Neon Medium** (not Opus/Max).
- Start a **fresh Composer thread** every time context crosses ~50% (never reuse one 500k-token chat all day).
- Use `@codebase` / quick lookups on Fast/Flash models, then paste only the 2–3 relevant files into a Hard/Reasoning model for tricky bugs.

## 5. Production Apps (Lens 2 — Zero Hardcoded Model IDs)
```js
import { callWithAutoEscalation } from './app-model-router.mjs';

const { output, receipt } = await callWithAutoEscalation({
  tier: 'fast',
  purpose: 'extract-invoice-json',
  execute: (route) => mySdk.generate({ model: route.model, reasoningEffort: route.effort, prompt }),
  validate: (out) => typeof out?.total === 'number' && Boolean(out?.vendor),
});
```
Swap any tier globally with **zero code edits** via `APP_MODEL_TIERS_JSON='{"fast":{"model":"gemini-4.5-flash","effort":"low"}}'` (applies on next container restart/redeploy, or immediately when backed by a runtime config store / KV).
