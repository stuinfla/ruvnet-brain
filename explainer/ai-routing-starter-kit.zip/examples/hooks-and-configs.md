# Drop-In Config & Hook Recipes (No MetaHarness Required)
Updated: 2026-11-22 EST

## 1. Claude Code (`~/.claude/settings.json`)
Park your main session on `sonnet` and add the 50% `⚡/compact` statusline guard:
```json
{
  "model": "sonnet",
  "statusLine": {
    "type": "command",
    "command": "node ~/.claude/statusline-50pct-compact.cjs"
  }
}
```

## 2. Codex CLI (`~/.codex/config.toml`)
Park Codex on `gpt-6.2-sol` (medium effort) and reserve `gpt-6.2-astra` for explicit escalations:
```toml
model = "gpt-6.2-sol"
model_reasoning_effort = "medium"
default_subagent_model = "gpt-6.2-sol"
```

## 3. Grok CLI (`~/.grok/config.toml`)
Park on `grok-4.7` (low/medium effort) and offload secondary work to `grok-build`:
```toml
model = "grok-4.7"
reasoning_effort = "low"
fork_secondary_model = "grok-build"
```

## 4. Antigravity (Gemini 4) & Cursor IDE
- **Antigravity:** Park default coordinator on `Gemini 4 Neon (Medium)`; delegate deep synthesis/reviews to `Gemini 4 Neon (High)` (`$0` cache-write fee) and broad scans to `Gemini 4 Flash`.
- **Cursor IDE (`.cursorrules` / Settings):** Park Composer on Sonnet 5.5 or Neon Medium; open a fresh thread at 50% context; pin only 2–3 relevant files when escalating to Hard/Reasoning.

## 5. Standalone `UserPromptSubmit` Hook + Weekly Cron (No MetaHarness Required)
Add a lightweight hook in `~/.claude/settings.json` to print the `[Routed: ...]` badge and log every decision to `~/.claude/metaharness/routing-decisions.jsonl` (read by `router-utilization.mjs`):
```json
{
  "hooks": {
    "UserPromptSubmit": [{ "hooks": [{ "type": "command", "command": "node ~/ai-routing-kit/standalone-router.mjs --hook" }] }]
  }
}
```
Schedule weekly freshness + watchdog checks via `crontab -e`:
```cron
0 2 * * 0 node ~/ai-routing-kit/model-auto-refresh.mjs --apply && node ~/ai-routing-kit/model-routing-audit.mjs
```

## 6. Production Apps & Corporate Pay-By-The-Drink (Fork 2 + Admin UI Picker)
```js
import { getProviderCatalog, setCapabilityOverride, callWithAutoEscalation } from './app-model-router.mjs';

// Optional Layer 1: Admin/Operator UI Picker backed by refreshable, cacheable /models catalog (zero redeploy)
const catalog = await getProviderCatalog({ refresh: true, ttlMs: 3600_000 });
setCapabilityOverride('extract-invoice-json', { provider: 'anthropic', model: 'claude-sonnet-5-5', effort: 'medium' });

// Layer 2 & 3: App code calls capability/tier aliases; falls back & auto-escalates automatically
const { output, receipt } = await callWithAutoEscalation({
  tier: 'fast',
  capability: 'extract-invoice-json',
  purpose: 'extract-invoice-json',
  execute: (route) => mySdk.generate({ provider: route.provider, model: route.model, reasoningEffort: route.effort, prompt }),
  validate: (out) => typeof out?.total === 'number' && Boolean(out?.vendor),
});
```
Swap any tier or capability globally with **zero code edits** via the Admin UI Picker (`setCapabilityOverride` / `APP_CAPABILITY_OVERRIDES_PATH`) or `APP_MODEL_TIERS_JSON`.
