#!/usr/bin/env node
// audit-my-ai-usage.mjs — Standalone zero-dependency 60-day AI Optimization Self-Test
// Timestamp: 2026-11-22 02:00 EST | Version 2.0.0
// Runs 100% locally (zero network calls). Scans your last 60 days of local transcripts across
// Claude Code, Codex, Antigravity/Gemini, and Grok, scores your current setup (0-100), and
// honestly tells you whether you're ALREADY well-optimized or leaving quota on the table.
// Usage: node audit-my-ai-usage.mjs

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const HOME = os.homedir();
const CUTOFF = Date.now() - 60 * 86400 * 1000;

function walk(dir, fn) {
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, fn);
    else fn(p, e.name);
  }
}

const claude = { turns: 0, frontierTurns: 0, midTurns: 0, fastTurns: 0, inTok: 0, cacheCreate: 0, cacheRead: 0, outTok: 0 };
walk(path.join(HOME, '.claude', 'projects'), (p, name) => {
  if (!name.endsWith('.jsonl')) return;
  let st; try { st = fs.statSync(p); } catch { return; }
  if (st.mtimeMs < CUTOFF || st.size > 60 * 1024 * 1024) return;
  for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    if (!line.includes('"usage"')) continue;
    try {
      const j = JSON.parse(line);
      const m = String(j?.message?.model || j?.model || '');
      const u = j?.message?.usage || j?.usage;
      if (!m || !u) continue;
      claude.turns++;
      if (/opus|fable/i.test(m)) claude.frontierTurns++;
      else if (/haiku/i.test(m)) claude.fastTurns++;
      else claude.midTurns++;
      claude.inTok += u.input_tokens || 0;
      claude.cacheCreate += u.cache_creation_input_tokens || 0;
      claude.cacheRead += u.cache_read_input_tokens || 0;
      claude.outTok += u.output_tokens || 0;
    } catch {}
  }
});

const codex = { sessions: 0, inTok: 0, cachedTok: 0, outTok: 0 };
walk(path.join(HOME, '.codex', 'sessions'), (p, name) => {
  if (!name.endsWith('.jsonl')) return;
  let st; try { st = fs.statSync(p); } catch { return; }
  if (st.mtimeMs < CUTOFF) return;
  codex.sessions++;
  let maxIn = 0, maxCached = 0, maxOut = 0;
  for (const line of fs.readFileSync(p, 'utf8').split('\n')) {
    if (!line.includes('token_count')) continue;
    try {
      const j = JSON.parse(line);
      const u = j?.payload?.info?.total_token_usage || j?.info?.total_token_usage;
      if (u) {
        maxIn = Math.max(maxIn, u.input_tokens || 0);
        maxCached = Math.max(maxCached, u.cached_input_tokens || 0);
        maxOut = Math.max(maxOut, u.output_tokens || 0);
      }
    } catch {}
  }
  codex.inTok += maxIn; codex.cachedTok += maxCached; codex.outTok += maxOut;
});

let grokSessions = 0, grokBytes = 0, agySessions = 0, agyBytes = 0;
walk(path.join(HOME, '.grok', 'sessions'), (p, name) => {
  if (!name.endsWith('.jsonl') && !name.endsWith('.json')) return;
  try { const st = fs.statSync(p); if (st.mtimeMs >= CUTOFF) { grokSessions++; grokBytes += st.size; } } catch {}
});
try {
  for (const e of fs.readdirSync(path.join(HOME, '.gemini', 'antigravity-cli', 'brain'), { withFileTypes: true })) {
    if (!e.isDirectory()) continue;
    const tp = path.join(HOME, '.gemini', 'antigravity-cli', 'brain', e.name, '.system_generated', 'logs', 'transcript.jsonl');
    if (fs.existsSync(tp)) {
      const st = fs.statSync(tp);
      if (st.mtimeMs >= CUTOFF) { agySessions++; agyBytes += st.size; }
    }
  }
} catch {}

const fmtB = (n) => n >= 1e9 ? `${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : `${n}`;
const claudeTotal = claude.inTok + claude.cacheCreate + claude.cacheRead + claude.outTok;
const claudeCacheHit = (claude.inTok + claude.cacheCreate + claude.cacheRead) > 0
  ? Math.round((claude.cacheRead / (claude.inTok + claude.cacheCreate + claude.cacheRead)) * 100) : 0;
const claudeFrontierPct = claude.turns ? Math.round((claude.frontierTurns / claude.turns) * 100) : 0;
const claudeFastPct = claude.turns ? Math.round((claude.fastTurns / claude.turns) * 100) : 0;
const codexCacheHit = codex.inTok > 0 ? Math.round((codex.cachedTok / codex.inTok) * 100) : 0;

// Compute an honest 0-100 Optimization Score (no hype: if they already score >=85, tell them!)
let score = 100;
const findings = [];
if (claude.turns > 50) {
  if (claudeFrontierPct > 20) {
    const pen = Math.min(40, Math.round((claudeFrontierPct - 20) * 1.1));
    score -= pen;
    findings.push(`-${pen} pts: ${claudeFrontierPct}% of Claude turns burned Frontier (Opus/Fable); target <=15-20%.`);
  }
  if (claudeFastPct < 15) {
    const pen = Math.min(20, Math.round((15 - claudeFastPct) * 1.3));
    score -= pen;
    findings.push(`-${pen} pts: Only ${claudeFastPct}% of Claude turns used Fast/Haiku (target 25-35% via subagent search isolation).`);
  }
  if (claude.cacheCreate > 200e6) {
    score -= 20;
    findings.push(`-20 pts: Heavy cache-write volume (${fmtB(claude.cacheCreate)}) — uncompacted >50% contexts are burning cache-write fees.`);
  }
}
score = Math.max(0, score);
const estStretch = score >= 85 ? '1.0x–1.2x (Already Well-Optimized!)' : score >= 60 ? '1.8x–2.8x' : '3.2x–4.5x';

console.log('\n=======================================================================');
console.log('  60-DAY LOCAL AI QUOTA & ROUTING SELF-TEST  (100% Local · Zero Upload)');
console.log('=======================================================================');
console.log(`Claude Code : ${claude.turns.toLocaleString()} turns | ${fmtB(claudeTotal)} tokens | ${claudeFrontierPct}% Frontier / ${claudeFastPct}% Fast | ${claudeCacheHit}% cache read`);
console.log(`Codex       : ${codex.sessions} sessions | ${fmtB(codex.inTok + codex.outTok)} tokens | ${codexCacheHit}% cache read`);
console.log(`Grok        : ${grokSessions} sessions | ${(grokBytes / 1048576).toFixed(1)} MB transcripts`);
console.log(`Antigravity : ${agySessions} sessions | ${(agyBytes / 1048576).toFixed(1)} MB transcripts`);
console.log('-----------------------------------------------------------------------');
console.log(`YOUR OPTIMIZATION SCORE : ${score} / 100`);
console.log(`ESTIMATED LICENSE GAIN  : ${estStretch}`);
if (findings.length) {
  console.log('\nWHERE QUOTA IS LEAKING:');
  for (const f of findings) console.log(`  • ${f}`);
}
console.log('\nVERDICT:');
if (score >= 85) {
  console.log('  ✓ YOUR CURRENT SETUP IS ALREADY GREAT. You do NOT need to overhaul your workflow—keep what works!');
} else {
  console.log('  → YOU ARE LEAVING SIGNIFICANT QUOTA ON THE TABLE. Paste SETUP-PROMPT.txt + this output into your AI assistant');
  console.log('    to review the base recipes in this kit and test a tailored setup on YOUR own prompts before changing anything.');
}
console.log('=======================================================================\n');
