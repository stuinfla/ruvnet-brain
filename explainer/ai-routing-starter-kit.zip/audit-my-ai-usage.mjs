#!/usr/bin/env node
// audit-my-ai-usage.mjs — Zero-dependency local 60-day AI subscription auditor (0–100 score).
// Scans Claude Code, Codex, Antigravity/Gemini, Grok, and Cursor logs locally. Zero data leaves your machine.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';

const HOME = os.homedir();
const NOW = Date.now();
const DAYS = Number(process.argv.find((a) => a.startsWith('--days='))?.split('=')[1] || 60);
const CUTOFF = NOW - DAYS * 86400 * 1000;
const JSON_OUT = process.argv.includes('--json');

function walkFiles(dir, exts, out = [], depth = 0) {
  if (depth > 5 || !fs.existsSync(dir)) return out;
  let entries;
  try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walkFiles(p, exts, out, depth + 1);
    else if (exts.some((ext) => e.name.endsWith(ext))) {
      try {
        const st = fs.statSync(p);
        if (st.mtimeMs >= CUTOFF) out.push({ path: p, size: st.size, mtimeMs: st.mtimeMs });
      } catch {}
    }
  }
  return out;
}

async function scanJsonlStream(filePath, onObj) {
  const rl = readline.createInterface({
    input: fs.createReadStream(filePath, { encoding: 'utf8' }),
    crlfDelay: Infinity,
  });
  for await (const line of rl) {
    if (!line || line.length > 2_000_000) continue;
    try { onObj(JSON.parse(line)); } catch {}
  }
}

async function scanClaude() {
  const files = walkFiles(path.join(HOME, '.claude', 'projects'), ['.jsonl']);
  let turns = 0, frontierTurns = 0, input = 0, cacheRead = 0, cacheWrite = 0, output = 0;
  for (const f of files) {
    await scanJsonlStream(f.path, (obj) => {
      const u = obj?.message?.usage;
      if (!u) return;
      const model = String(obj?.message?.model || '').toLowerCase();
      turns++;
      if (/opus|fable/.test(model)) frontierTurns++;
      input += u.input_tokens || 0;
      cacheRead += u.cache_read_input_tokens || 0;
      cacheWrite += u.cache_creation_input_tokens || 0;
      output += u.output_tokens || 0;
    });
  }
  const totalIn = input + cacheRead + cacheWrite;
  return {
    tool: 'Claude Code',
    detected: files.length > 0,
    files: files.length,
    turns,
    frontierPct: turns ? +((frontierTurns / turns) * 100).toFixed(1) : 0,
    warmCachePct: totalIn ? +((cacheRead / totalIn) * 100).toFixed(1) : 0,
    cacheWritePct: totalIn ? +((cacheWrite / totalIn) * 100).toFixed(1) : 0,
    totalTokensM: +((totalIn + output) / 1e6).toFixed(1),
  };
}

async function scanCodex() {
  const files = walkFiles(path.join(HOME, '.codex', 'sessions'), ['.jsonl']);
  let turns = 0, frontierTurns = 0, totalTokens = 0, cachedTokens = 0;
  for (const f of files) {
    await scanJsonlStream(f.path, (obj) => {
      const m = String(obj?.model || obj?.payload?.model || '').toLowerCase();
      const u = obj?.payload?.info?.last_token_usage || obj?.usage;
      if (u && (u.input_tokens || u.total_tokens)) {
        turns++;
        if (/astra|pro|o1|o3|xhigh/.test(m)) frontierTurns++;
        totalTokens += (u.total_tokens || ((u.input_tokens || 0) + (u.output_tokens || 0)));
        cachedTokens += (u.cached_input_tokens || 0);
      }
    });
  }
  return {
    tool: 'Codex CLI',
    detected: files.length > 0,
    files: files.length,
    turns,
    frontierPct: turns ? +((frontierTurns / turns) * 100).toFixed(1) : 0,
    warmCachePct: totalTokens ? +((cachedTokens / totalTokens) * 100).toFixed(1) : 0,
    totalTokensM: +(totalTokens / 1e6).toFixed(1),
  };
}

function scanSimpleDir(tool, dirs, exts) {
  let files = [];
  for (const d of dirs) files = files.concat(walkFiles(d, exts));
  const totalMB = +(files.reduce((s, f) => s + f.size, 0) / 1e6).toFixed(1);
  return { tool, detected: files.length > 0, files: files.length, totalMB };
}

const claude = await scanClaude();
const codex = await scanCodex();
const antigravity = scanSimpleDir('Antigravity / Gemini', [path.join(HOME, '.gemini', 'antigravity-cli', 'brain'), path.join(HOME, '.gemini', 'tmp')], ['.jsonl', '.json']);
const grok = scanSimpleDir('Grok CLI', [path.join(HOME, '.grok')], ['.jsonl', '.json']);
const cursor = scanSimpleDir('Cursor IDE', [
  path.join(HOME, 'Library', 'Application Support', 'Cursor', 'User', 'workspaceStorage'),
  path.join(HOME, '.config', 'Cursor', 'User', 'workspaceStorage'),
], ['.vscdb', '.json']);

// Check if any paid API keys are leaked in shell env for personal coding
const leakedKeys = ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'OPENROUTER_API_KEY', 'XAI_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY']
  .filter((k) => Boolean(process.env[k]));

// Honest scoring across ALL detected tools (NEVER returns 100/100 when 0 measured turns!)
const totalMeasuredTurns = claude.turns + codex.turns;
const anyDetected = [claude, codex, antigravity, grok, cursor].some((t) => t.detected);
const findings = [];
let score = totalMeasuredTurns >= 20 ? 100 : null;

if (score !== null) {
  if (leakedKeys.length > 0) {
    score -= 15;
    findings.push(`Paid API keys active in shell env (${leakedKeys.join(', ')}) — risk of double-paying on top of prepaid seats.`);
  }
  if (claude.turns >= 20) {
    if (claude.frontierPct > 25) {
      score -= Math.min(35, Math.round((claude.frontierPct - 15) * 0.8));
      findings.push(`Claude Frontier share is ${claude.frontierPct}% (target: <=15%). Park main chat on Sonnet + offload searches to Haiku.`);
    }
    if (claude.cacheWritePct > 5) {
      score -= Math.min(20, Math.round(claude.cacheWritePct * 1.5));
      findings.push(`Claude cache-write share is ${claude.cacheWritePct}% of input (target: <3%). Compact sessions at 50% context.`);
    }
  }
  if (codex.turns >= 20 && codex.frontierPct > 25) {
    score -= Math.min(25, Math.round((codex.frontierPct - 15) * 0.7));
    findings.push(`Codex Frontier share is ${codex.frontierPct}% (target: <=15%). Default Codex to Sol medium + reserve Astra for escalations.`);
  }
  score = Math.max(5, Math.min(100, score));
} else if (anyDetected) {
  findings.push(`Found local workspace files but only ${totalMeasuredTurns} token-level turns (minimum 20 required for a reliable 0-100 score).`);
  if (leakedKeys.length > 0) findings.push(`Paid API keys active in shell env (${leakedKeys.join(', ')}) — strip for prepaid coding.`);
}

const verdict = score === null
  ? 'INSUFFICIENT TOKEN TELEMETRY (<20 measured turns) — run on your primary coding machine or pass --days=90'
  : score >= 85
    ? 'ALREADY WELL OPTIMIZED — keep what works, adopt only the pieces you like'
    : score >= 60
      ? 'MODERATE LEAKAGE — 2x–3x license stretch available with 5-tier routing + 50% /compact'
      : 'HIGH QUOTA LEAKAGE — 3.5x–4.5x license stretch available immediately';

const report = { auditedAt: new Date().toISOString(), windowDays: DAYS, score, verdict, leakedKeys, tools: { claude, codex, antigravity, grok, cursor }, findings };
if (JSON_OUT) {
  console.log(JSON.stringify(report, null, 2));
} else {
  console.log(`\n=== AI Subscription Usage Audit (${DAYS}-day window · local only) ===`);
  console.log(`Score:   ${score === null ? 'N/A' : score + ' / 100'}`);
  console.log(`Verdict: ${verdict}`);
  console.log(`Tools:   Claude(${claude.turns} turns, ${claude.frontierPct}% frontier) | Codex(${codex.turns} turns, ${codex.frontierPct}% frontier) | Antigravity(${antigravity.files} files) | Grok(${grok.files} files) | Cursor(${cursor.files} files)`);
  if (findings.length) {
    console.log('\nTop Findings:');
    findings.forEach((f, i) => console.log(`  ${i + 1}. ${f}`));
  }
  console.log('');
}
