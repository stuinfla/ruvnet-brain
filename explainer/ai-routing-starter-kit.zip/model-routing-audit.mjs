#!/usr/bin/env node
// model-routing-audit.mjs — Standalone 10/13-point model routing self-audit watchdog.
// Auto-detects ~/.claude/model-router/ (MetaHarness) OR runs against local starter-kit files.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { routePrompt } from './standalone-router.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const HOME = os.homedir();
const mhPolicy = path.join(HOME, '.claude', 'model-router', 'routing-policy.json');
const kitPolicy = path.join(__dirname, 'routing-policy.template.json');
const policyPath = fs.existsSync(mhPolicy) ? mhPolicy : kitPolicy;
const mode = fs.existsSync(mhPolicy) ? 'installed-metaharness' : 'standalone-starter-kit';

const checks = [];
function add(id, ok, detail) { checks.push({ id, ok: Boolean(ok), detail }); }

const policy = JSON.parse(fs.readFileSync(policyPath, 'utf8'));
const TIERS = ['fast', 'medium', 'substantial', 'hard', 'exceptional'];
const hosts = Object.keys(policy.routes || {});
add('policy-loaded', hosts.length >= 4, `${hosts.length} hosts configured (${hosts.join(', ')})`);

// Verify all 20 required host x tier routes have non-empty model & effort (prevents empty-object false pass!)
let validRoutes = 0;
const missingRoutes = [];
for (const h of hosts) {
  for (const t of TIERS) {
    const r = policy.routes?.[h]?.[t];
    if (r && typeof r.model === 'string' && r.model.trim() && typeof r.effort === 'string' && r.effort.trim()) {
      validRoutes++;
    } else {
      missingRoutes.push(`${h}.${t}`);
    }
  }
}
add('all-20-routes-populated', hosts.length >= 4 && missingRoutes.length === 0, missingRoutes.length === 0 ? `${validRoutes}/${hosts.length * 5} host×tier routes populated` : `Missing: ${missingRoutes.slice(0, 6).join(', ')}`);

// Verify declared policy freshness (not just file mtime!)
const declaredTs = policy.policyRevisionAt || policy.reviewedAt || policy.updated_at;
const parsedMs = declaredTs ? Date.parse(declaredTs) : NaN;
const ageDays = Number.isFinite(parsedMs) ? Math.max(0, Math.floor((Date.now() - parsedMs) / 86400000)) : 999;
add('policy-freshness', ageDays <= 7, Number.isFinite(parsedMs) ? `Policy date ${String(declaredTs).slice(0, 10)} (${ageDays}d old, limit <=7d)` : 'Missing reviewedAt/policyRevisionAt timestamp');

const leakedKeys = ['ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'OPENROUTER_API_KEY', 'XAI_API_KEY', 'GEMINI_API_KEY', 'GOOGLE_API_KEY']
  .filter((k) => Boolean(process.env[k]));
add('zero-api-key-leak', leakedKeys.length === 0, leakedKeys.length === 0 ? 'No paid API keys active in shell env' : `Found: ${leakedKeys.join(', ')}`);

// Verify no routine tier defaults to max/xhigh
let effortViolations = 0;
for (const h of hosts) {
  for (const tier of ['fast', 'medium', 'substantial', 'hard']) {
    const eff = String(policy.routes?.[h]?.[tier]?.effort || '').toLowerCase();
    if (eff === 'max' || eff === 'xhigh') effortViolations++;
  }
}
add('effort-caps', effortViolations === 0, effortViolations === 0 ? 'No routine tier exceeds high thinking effort' : `${effortViolations} effort cap violations`);

// Run 36-case eval suite
const evalPath = path.join(__dirname, 'routing-eval-cases.json');
const evalCases = JSON.parse(fs.readFileSync(evalPath, 'utf8'));
const list = Array.isArray(evalCases) ? evalCases : (evalCases.cases || []);
const ORDER = ['fast', 'medium', 'substantial', 'hard', 'exceptional'];
let passed = 0;
for (const c of list) {
  const exp = c.expected || c.expectedClass || c.tier;
  const r = routePrompt(c.request || c.prompt || c.taskHints || '', { priorFailure: Boolean(c.priorFailure), taskFacts: c.taskFacts, policyPath });
  const idx = ORDER.indexOf(r.tier);
  const ok = typeof exp === 'string'
    ? r.tier === exp
    : (idx >= (exp?.minimumClass ? ORDER.indexOf(exp.minimumClass) : 0) && idx <= (exp?.maximumClass ? ORDER.indexOf(exp.maximumClass) : 4));
  if (ok) passed++;
}
add('eval-suite', passed === list.length && list.length > 0, `${passed}/${list.length} safety eval cases passed`);

// Live escalation check
const esc = routePrompt('still broken, tests failed twice on auth middleware', { priorFailure: true, policyPath });
add('auto-escalation', esc.escalated === true, `Escalated to ${esc.tier} (${esc.model}@${esc.effort})`);

// Checks 8-13: Fork 2 fallback integrity, kit examples, statusline guard, cloud proxy off, refresh script, utilization script
const appRouterSrc = fs.existsSync(path.join(__dirname, 'app-model-router.mjs')) ? fs.readFileSync(path.join(__dirname, 'app-model-router.mjs'), 'utf8') : '';
add('app-router-fallback-provider', appRouterSrc.includes('fallbackProvider'), 'app-model-router.mjs defines cross-provider fallbackProvider');
add('hooks-examples-present', fs.existsSync(path.join(__dirname, 'examples', 'hooks-and-configs.md')), 'examples/hooks-and-configs.md present for all 5 tools');
add('statusline-compact-guard', fs.existsSync(path.join(__dirname, 'examples', 'statusline-50pct-compact.cjs')), '50% ⚡/compact statusline guard script present');
add('auto-refresh-script', fs.existsSync(path.join(__dirname, 'model-auto-refresh.mjs')), 'model-auto-refresh.mjs freshness scanner present');
add('utilization-tracker', fs.existsSync(path.join(__dirname, 'router-utilization.mjs')), 'router-utilization.mjs 7d vs 60d tracker present');
add('cloud-proxy-off-locally', !process.env.META_PROXY_CLOUD_URL && !process.env.OPENROUTER_BASE_URL, 'Paid cloud proxy env vars OFF locally ($0 subscription safety)');

const allOk = checks.every((c) => c.ok);
const alerts = checks.filter((c) => !c.ok).map((c) => `ALERT [${c.id}]: ${c.detail}`);
console.log(JSON.stringify({ ok: allOk, mode, policyPath, passed: checks.filter((c) => c.ok).length, total: checks.length, alerts, checks }, null, 2));
process.exit(allOk ? 0 : 1);
