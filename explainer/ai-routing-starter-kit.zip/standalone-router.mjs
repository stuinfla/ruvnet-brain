#!/usr/bin/env node
// standalone-router.mjs — Zero-dependency 5-tier local prompt router & 36-case safety eval runner.
// Usage:
//   node standalone-router.mjs --prompt "read package.json and check git status"
//   node standalone-router.mjs --prompt "still broken, tests failed twice" --prior-failure
//   node standalone-router.mjs --eval
//   node standalone-router.mjs --json --prompt "design a zero-downtime DB migration"

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { classify } from './policy.default.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TIER_ORDER = ['fast', 'medium', 'substantial', 'hard', 'exceptional'];
const NEXT_TIER = { fast: 'medium', medium: 'substantial', substantial: 'hard', hard: 'exceptional' };

export function extractFeatures(prompt = '', taskFacts = undefined) {
  const s = String(prompt || '').trim();
  const hasCode = /```/.test(s) || /\b(function|const|let|var|class|import|export|SELECT|CREATE TABLE)\b/.test(s);
  return {
    taskHints: s,
    hasCode,
    chars: s.length,
    ...(taskFacts ? { taskFacts } : {}),
  };
}

export function routePrompt(prompt, { host = 'claude-code', priorFailure = false, taskFacts = undefined, policyPath = null } = {}) {
  const features = extractFeatures(prompt, taskFacts);
  let tier = classify(features, host);
  const failSignal = /\b(still\s+(broken|failing|wrong|stuck)|failed\s+twice|didn'?t\s+work|same\s+error|try\s+harder|escalate)\b/i.test(prompt);
  let escalated = false;
  if (priorFailure && NEXT_TIER[tier]) {
    tier = NEXT_TIER[tier];
    escalated = true;
  } else if (failSignal && (tier === 'hard' || tier === 'exceptional')) {
    escalated = true;
  }
  const tplPath = policyPath || path.join(__dirname, 'routing-policy.template.json');
  let target = { model: 'tier-' + tier, effort: tier === 'fast' ? 'low' : tier === 'medium' ? 'medium' : 'high' };
  if (fs.existsSync(tplPath)) {
    try {
      const tpl = JSON.parse(fs.readFileSync(tplPath, 'utf8'));
      const hostRoutes = tpl.routes?.[host] || tpl.routes?.['claude-code'];
      if (hostRoutes?.[tier]) target = hostRoutes[tier];
    } catch {}
  }
  let effort = target.effort || 'medium';
  if (host === 'claude-code' && tier === 'medium' && features.hasCode) effort = 'high';
  return { tier, escalated, host, model: target.model, effort, costUsd: 0 };
}

function tierInRange(got, exp) {
  if (!exp) return false;
  if (typeof exp === 'string') return got === exp;
  if (Array.isArray(exp)) return exp.includes(got);
  const idx = TIER_ORDER.indexOf(got);
  const min = exp.minimumClass ? TIER_ORDER.indexOf(exp.minimumClass) : 0;
  const max = exp.maximumClass ? TIER_ORDER.indexOf(exp.maximumClass) : TIER_ORDER.length - 1;
  return idx >= min && idx <= max;
}

const isDirect = Boolean(process.argv[1] && fs.existsSync(process.argv[1]) && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url)));
if (isDirect) {
  const args = process.argv.slice(2);
  if (args.includes('--hook')) {
    let raw = '';
    try { raw = fs.readFileSync(0, 'utf8'); } catch {}
    let payload = {};
    try { payload = JSON.parse(raw || '{}'); } catch { payload = { prompt: raw }; }
    const prompt = String(payload.prompt || payload.user_prompt || '').trim();
    const hIdx = args.indexOf('--host');
    const host = hIdx >= 0 ? args[hIdx + 1] : 'claude-code';
    const res = routePrompt(prompt, { host });
    const decFile = process.env.MODEL_ROUTER_DECISIONS || path.join(os.homedir(), '.claude', 'metaharness', 'routing-decisions.jsonl');
    try {
      fs.mkdirSync(path.dirname(decFile), { recursive: true });
      fs.appendFileSync(decFile, JSON.stringify({ ts: new Date().toISOString(), host, taskClass: res.tier, model: res.model, effort: res.effort, escalated: res.escalated }) + '\n');
    } catch {}
    const badge = `[Routed: ${res.tier} -> ${res.model} (${res.effort} thinking) · $0 subscription]`;
    console.log(JSON.stringify({ hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: `${badge} — Follow 4 quota-hygiene rules (isolate >5-file scans in fast subagents, compact at 50% ctx, pre-distill escalations, preserve warm cache).` } }));
    process.exit(0);
  }
  if (args.includes('--eval')) {
    const casesPath = path.join(__dirname, 'routing-eval-cases.json');
    const raw = JSON.parse(fs.readFileSync(casesPath, 'utf8'));
    const cases = Array.isArray(raw) ? raw : (raw.cases || []);
    let passed = 0;
    const failures = [];
    for (const c of cases) {
      const expected = c.expected || c.expectedClass || c.tier;
      const res = routePrompt(c.request || c.prompt || c.taskHints || '', {
        priorFailure: Boolean(c.priorFailure),
        taskFacts: c.taskFacts,
      });
      const ok = tierInRange(res.tier, expected);
      if (ok) passed++;
      else failures.push({ id: c.id || String(c.prompt || '').slice(0, 40), expected, got: res.tier });
    }
    console.log(JSON.stringify({ ok: failures.length === 0, passed, total: cases.length, failures }, null, 2));
    process.exit(failures.length === 0 ? 0 : 1);
  }
  const pIdx = args.indexOf('--prompt');
  const prompt = pIdx >= 0 ? args[pIdx + 1] : args.filter((a) => !a.startsWith('--')).join(' ');
  const hIdx = args.indexOf('--host');
  const host = hIdx >= 0 ? args[hIdx + 1] : 'claude-code';
  const res = routePrompt(prompt || 'check git status', { host, priorFailure: args.includes('--prior-failure') });
  console.log(JSON.stringify(res, null, 2));
}
