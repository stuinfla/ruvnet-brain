#!/usr/bin/env node
// router-utilization.mjs — Standalone Before-vs-After routing tier distribution analyzer.
// Reads ~/.claude/metaharness/routing-decisions.jsonl (or --file <path>) and prints tier shares.

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const args = process.argv.slice(2);
const fIdx = args.indexOf('--file');
const file = fIdx >= 0 ? args[fIdx + 1] : path.join(os.homedir(), '.claude', 'metaharness', 'routing-decisions.jsonl');

if (!fs.existsSync(file)) {
  console.log(JSON.stringify({
    ok: true,
    status: 'no-decisions-log-yet',
    file,
    note: 'Once your prompt hook logs JSONL decisions, run this script to compare 7-day vs 60-day tier distribution.',
  }, null, 2));
  process.exit(0);
}

const now = Date.now();
const d7 = now - 7 * 86400 * 1000;
const d60 = now - 60 * 86400 * 1000;
const makeBucket = () => ({ total: 0, counts: { fast: 0, medium: 0, substantial: 0, hard: 0, exceptional: 0 } });
const all = makeBucket(), last7d = makeBucket(), prior60d = makeBucket();
for (const line of fs.readFileSync(file, 'utf8').split('\n')) {
  if (!line.trim()) continue;
  try {
    const d = JSON.parse(line);
    const k = d.taskClass || d.tier;
    if (!k || !(k in all.counts)) continue;
    all.counts[k]++; all.total++;
    const ts = Date.parse(d.ts || d.timestamp || d.at || '');
    if (Number.isFinite(ts)) {
      if (ts >= d7) { last7d.counts[k]++; last7d.total++; }
      else if (ts >= d60) { prior60d.counts[k]++; prior60d.total++; }
    }
  } catch {}
}
const toPct = (b) => ({
  total: b.total,
  pcts: Object.fromEntries(Object.entries(b.counts).map(([k, v]) => [k, b.total ? +((v / b.total) * 100).toFixed(1) : 0])),
});
console.log(JSON.stringify({ ok: true, allTime: toPct(all), last7d: toPct(last7d), prior60d: toPct(prior60d) }, null, 2));
